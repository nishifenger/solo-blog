title: HBase连续分页查询，跳过上一次查询结果最后一行数据的实现方法
date: '2019-10-28 09:35:03'
updated: '2019-10-29 22:42:54'
tags: [hbase, java, api, 分页查询]
permalink: /articles/2019/10/28/1572226503511.html
---
![3840x2160TendoKisara动漫少女4K壁纸彼岸图网.jpg](https://img.hacpai.com/file/2019/10/3840x2160TendoKisara动漫少女4K壁纸彼岸图网-37f6a8a6.jpg)
# HBase连续分页查询，跳过上一次查询结果最后一行数据的实现方法
使用HBase Java Api实现分页查询时，当我们查询第n+1页数据时，会将第n页最后一行数据的rowKey作为此次查询的startRow。然而此方法查询的结果中会包含第n页的最后一行数据。很多开发人员解决此问题的方法是，查询第n+1页数据是就多取一条数据，返回数据时，将第一条数据删除。这种方法虽然能够得到正确的结果，但是操作较为复杂。

其实在《HBase权威指南》一书中，***Lars* *George*** 先生已经给出了此问题的标准答案。
> HBase中的行健是按字典序排列的，因此返回的结果也是如此排序的，并且起始行是被包含在结果中的。用户需要拼接一个零字节（一个长度为零的字节数组）到之前的行健，这样可以保证最后返回的行在本轮扫描时不被包括。但重置扫描的边界时，零字节是最聪明可靠的方式，因为零字节是最小的增幅。即使有一行的行健正好与之前一行加零字节相同，在这一轮循环是也不会有问题，因为起始行在扫描时是被包括在内的。**[1]摘抄自HBase权威指南（中文版）. Lars George[美国].2013年10月第一版**

从上面的描述可以得到，只要我们在第n页最后一行数据的rowKey的基础上加上一个长度为零的字节数组作为此次查询的startRow，就可以取到我们想要的数据。

可能很多人跟我的想法是一样的，一个长度为零的字节数组。哈，这么简单！然后就写出下面的代码：

```
byte startRow = Bytes.add(lastEndRow, new byte[0]);
```
然后你会发现，你这样写并不能跳过lastEndRow这一行数据。正确的写法应是下面这样的（源自《HBase权威指南》书附带的源代码，[传送门](https://github.com/larsgeorge/hbase-book/blob/master/ch04/src/main/java/filters/PageFilterExample.java)）：

```
byte startRow = Bytes.add(lastEndRow, new byte[] {0x00});
```
那么为什么这么写，就可以呢。我们首先看一下 new byte[] {0x00}是什么鬼。测试代码如下：

```
private static final byte[] POSTFIX = new byte[] {0x00};

@Test
public void byteTest(){
    System.out.println(POSTFIX.length);
    System.out.println(Bytes.toString(POSTFIX));
}
```
输出结果如下图所示：

![type.png](https://img.hacpai.com/file/2019/10/type-5960c147.png)


从图中可以看到，其length是1，不是0。转换成字符串是有内容的，但是看不到！

那么从此可以看出零字节并不是一个长度为零的字节数组，难道书中所述有问题，还是翻译有问题。

找到了英文版原著 ***HBase The Definitive Guide***，找到对应的文段，英文原文如下：
> Because of the lexicographical sorting of the row keys by HBase and the comparison
taking care of finding the row keys in order, and the fact that the start key on a scan is always inclusive, you need to add an extra zero byte to the previous key. This will ensure
that the last seen row key is skipped and the next, in sorting order, is found. The zero
byte is the smallest increment, and therefore is safe to use when resetting the scan
boundaries. Even if there were a row that would match the previous plus the extra zero
byte, the scan would be correctly doing the next iteration—this is because the start
key is inclusive.**[2] HBase The Definitive Guide. Lars George, 2011.9**

从英文原来来看，原作者并未说零字节就是一个长度为零的字节数组。所以鄙人妄自推测，是译者的翻译有误。看来，技术翻译并不是那么简单。相反，作为一个技术翻译，需要十分的谨慎仔细，不然会误导读者。
