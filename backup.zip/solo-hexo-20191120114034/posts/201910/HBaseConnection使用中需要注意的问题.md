title: HBase Connection使用中需要注意的问题
date: '2019-10-28 10:51:34'
updated: '2019-10-28 10:53:52'
tags: [hbase, java, api, connection]
permalink: /articles/2019/10/28/1572231094567.html
---
![可爱蓝色眼睛动漫女生4K壁纸彼岸图网.jpg](https://img.hacpai.com/file/2019/10/可爱蓝色眼睛动漫女生4K壁纸彼岸图网-46181f6b.jpg)

# HBase Connection使用中需要注意的问题

## 一、Connection基本概念及个人理解
HBase Connection也就是HBase的连接，首先看一下源代码上的注释，了解Connection的相关信息。
源代码注释如下：

```
/**
 * A cluster connection encapsulating lower level individual connections to actual servers and
 * a connection to zookeeper. Connections are instantiated through the {@link ConnectionFactory}
 * class. The lifecycle of the connection is managed by the caller, who has to {@link #close()}
 * the connection to release the resources.
 *
 * <p> The connection object contains logic to find the master, locate regions out on the cluster,
 * keeps a cache of locations and then knows how to re-calibrate after they move. The individual
 * connections to servers, meta cache, zookeeper connection, etc are all shared by the
 * {@link Table} and {@link Admin} instances obtained from this connection.
 *
 * <p> Connection creation is a heavy-weight operation. Connection implementations are thread-safe,
 * so that the client can create a connection once, and share it with different threads.
 * {@link Table} and {@link Admin} instances, on the other hand, are light-weight and are not
 * thread-safe.  Typically, a single connection per client application is instantiated and every
 * thread will obtain its own Table instance. Caching or pooling of {@link Table} and {@link Admin}
 * is not recommended.
 *
 * <p>This class replaces {@link HConnection}, which is now deprecated.
 * @see ConnectionFactory
 * @since 0.99.0
 */
```
大概意思可以总结为一下几点：
- 集群连接将更低层的个体连接封装到实际的服务器上，并连接到zookeeper。
- Connection的生命周期需要调用者去管理，且必须close释放资源。
- Connection是一个重量级的操作，但是线程安全的，客户端可以创建一次连接，Table和Admin分享这个Connection。因为Table和Admin的创建操作是轻量级以及线程不安全的。

个人觉得，可以这么理解：一个Connection相当于一个进程，而在此Connection上创建的Table相对于此进程中的一个线程。

## 二、Connection的使用方法
### 2.1 源代码中给出的示例使用方法
源代码中给出的示例使用方法代码如下：

```
Connection connection = ConnectionFactory.createConnection();
Table table = connection.getTable(TableName.valueOf("mytable"));
try {
  table.get(...);
  ...
  } finally {
  table.close();
  connection.close();
  }
```
从代码中，可以看到，使用完Connection后，需要将其close。但是这样写法，存在的问题就是，每次查询都需要创建一个连接。而创建连接又是一个重量级操作，消耗较多资源和时间。既然可以多个Table共享一个Connection，是否可以创建一次Connection，待所有查询完毕之后，再关闭呢？答案是肯定的。

### 2.2 Connection单例使用方法
简单的说，就是只创建一个Connection对象，当其为null或是Connection实例被close的情况下，再重新实例化一个新的Connection。总之，整个生命周期中，只有一个Connection实例。

使用Connection获取Table实例代码如下：

```
private Table getTable(String tableName) throws IOException {
        return connectionFactory.getConnection().getTable(TableName.valueOf(tableName));
    }
```
在用Connection获取Table实例之后，并未将其关闭。

这样用法的好处在于，除了系统初始后后的第一次查询需要创建连接，之后的查询都不需要创建连接，节省了创建连接的时间和系统资源。提高了查询效率。且对于大量数据的报表导出业务来讲，效率提高更加明显。因为在进行报表导出需要分批次查询数据。比如：用户一次性需要导出300万条数据，每次查询10万条，则需要查询30次。若每次连接的建立需要1s，则可以节省30秒的时间。

但是此方法也是存在问题的，个人觉得有以下几个问题：
- Connection始终不关闭，那么资源什么时候释放。当我们的应用关闭之后，HBase会释放资源吗？这一点需要进一步分析。
- 一个应用只用一个Connection，其支持的并发量是多少，是否能够满足并发需求？
- 对于并发的查询访问，其查询是并行，还是串行？

其实以上两种方法都有一定的问题，最好的方式，个人觉得应该是通过自定义的Connection资源池去管理多个Connection以及Connection的创建个关闭。后续会进一步探索。

下面将通过实验，对部分问题进行分析。

## 三、实验
实验环境如下：
HBase版本：1.1.2

HBase Api版本：1.1.2

集群管理平台：HDP-2.5

Connection创建代码如下：

```
class HBaseConnectionHelper {

    private static final Logger LOGGER = LoggerFactory.getLogger(HBaseConnectionHelper.class);

    private static Connection connection = null;

    private HBaseConnectionHelper() {}

    static Connection getHBaseConnection() throws IOException {
        if (connection == null || connection.isClosed()) {
            LOGGER.info("connection is not exit or closed, create a new connection");
            synchronized (HBaseConnectionHelper.class) {
                if (connection == null || connection.isClosed()) {
                    LOGGER.info("synchronized : connection is not exit or closed, create a new connection");
                    Configuration configuration = HBaseConfiguration.create();
                    connection = ConnectionFactory.createConnection(configuration);
                }
            }
        }
        LOGGER.info("connection is exit and not closed");
        return connection;
    }
}
```
Table实例获取代码如下：

```
public static Table getTable(String tableName) throws IOException {
        Table table = getHBaseConnection()
                .getTable(TableName.valueOf(tableName));
        LOGGER.info("get table time is {}", System.currentTimeMillis());
        return table;
    }
```

### 3.1 关闭Connection之后，是否会创建一个新的
通过两次连续查询，每次查询完之后，都将Connection进行关闭。
部分测试结果如下，我只摘取了Connection创建的日志，可见Connection是被创建了两次的。

```
[main] INFO org.apache.zookeeper.ZooKeeper - Initiating client connection, connectString=127.0.0.1:2181,127.0.0.1:2182,127.0.0.1:2183 sessionTimeout=90000 watcher=hconnection-0x481a15ff0x0, quorum=127.0.0.1:2181,127.0.0.1:2182,127.0.0.1:2183, baseZNode=/hbase-unsecure
[main-SendThread(127.0.0.1:2181)] INFO org.apache.zookeeper.ClientCnxn - Opening socket connection to server 127.0.0.1:2181. Will not attempt to authenticate using SASL (unknown error)
[main-SendThread(127.0.0.1:2181)] INFO org.apache.zookeeper.ClientCnxn - Socket connection established to 127.0.0.1:2181, initiating session
[main-SendThread(127.0.0.1:2181)] INFO org.apache.zookeeper.ClientCnxn - Session establishment complete on server 127.0.0.1:2181, sessionid = 0x25fa03db2043481, negotiated timeout = 40000

[main] INFO org.apache.zookeeper.ZooKeeper - Initiating client connection, connectString=127.0.0.1:2181,127.0.0.1:2182,127.0.0.1:2183 sessionTimeout=90000 watcher=hconnection-0x481a15ff0x0, quorum=127.0.0.1:2181,127.0.0.1:2182,127.0.0.1:2183, baseZNode=/hbase-unsecure
[main-SendThread(127.0.0.1:2181)] INFO org.apache.zookeeper.ClientCnxn - Opening socket connection to server 127.0.0.1:2181. Will not attempt to authenticate using SASL (unknown error)
[main-SendThread(127.0.0.1:2181)] INFO org.apache.zookeeper.ClientCnxn - Socket connection established to 127.0.0.1:2181, initiating session
[main-SendThread(127.0.0.1:2181)] INFO org.apache.zookeeper.ClientCnxn - Session establishment complete on server 127.0.0.1:2181, sessionid = 0x25fa03db2043481, negotiated timeout = 40000
```

### 3.2 单个Connection，并发查询是并行还是串行
测试代码如下：


```
public class QueryHBaseThread extends Thread {

    private static final Logger LOGGER = LoggerFactory.getLogger(QueryHBaseThread.class);

    @Override
    public void run() {
        long startTime = System.currentTimeMillis();
        HBaseHelper.queryByPage_normal();
        LOGGER.info("thread cost time is {}", System.currentTimeMillis() - startTime);
    }
}
```


```
public class ThreadTest {
    public static void main (String [] args) throws InterruptedException {
        QueryHBaseThread thread1 = new QueryHBaseThread();
        QueryHBaseThread thread2 = new QueryHBaseThread();
        QueryHBaseThread thread3 = new QueryHBaseThread();

        thread1.start();
        Thread.sleep(10000);
        thread2.start();
        thread3.start();
    }
}
```
测试结果如下，从结果中可以看到Thread-1和Thread-2获取的Table实例和scanner实例的时间基本一致。两个查询的时长也相差不多。可见，单个Connection的并发查询是并行的。

```
[Thread-0] INFO com.test.HBaseConnectionHelper - connection is exit and not closed
[Thread-0] INFO com.test.HBaseHelper - get table time is 1516873498227
[Thread-0] INFO com.test.HBaseHelper - get scanner time is 1516873499328
[Thread-1] INFO com.test.HBaseConnectionHelper - connection is exit and not closed
[Thread-1] INFO com.test.HBaseHelper - get table time is 1516873506579
[Thread-2] INFO com.test.HBaseConnectionHelper - connection is exit and not closed
[Thread-2] INFO com.test.HBaseHelper - get table time is 1516873506580
[Thread-1] INFO com.test.HBaseHelper - get scanner time is 1516873509077
[Thread-2] INFO com.test.HBaseHelper - get scanner time is 1516873509077
[Thread-0] INFO com.test.HBaseHelper - data count = 10000
[Thread-0] INFO com.test.HBaseHelper - for cost time is 103579ms
[Thread-0] INFO com.test.HBaseHelper - query cost time is 104678ms
[Thread-0] INFO com.test.QueryHBaseThread - thread cost time is 106328
[Thread-2] INFO com.test.HBaseHelper - data count = 10000
[Thread-2] INFO com.test.HBaseHelper - for cost time is 98628ms
[Thread-2] INFO com.test.HBaseHelper - query cost time is 101126ms
[Thread-2] INFO com.test.QueryHBaseThread - thread cost time is 101127
[Thread-1] INFO com.test.HBaseHelper - data count = 10000
[Thread-1] INFO com.test.HBaseHelper - for cost time is 101588ms
[Thread-1] INFO com.test.HBaseHelper - query cost time is 104086ms
[Thread-1] INFO com.test.QueryHBaseThread - thread cost time is 104086
```
