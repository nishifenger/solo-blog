title: hadoop archive报java堆内存溢出的解决方案
date: '2019-11-04 17:33:47'
updated: '2019-11-04 17:33:47'
tags: [hadoop, hdfs, archive]
permalink: /articles/2019/11/04/1572860027113.html
---
# hadoop archive报java堆内存溢出的解决方案
执行hadoop archive命令报错如下：

```
19/10/30 22:18:22 WARN ipc.Client: Unexpected error reading responses on connection Thread[IPC Client (1620948027) connection to master1.com.cn/192.168.189.15:8020 from iotcdh,5,main]
java.lang.OutOfMemoryError: Java heap space
	at com.google.protobuf.CodedInputStream.<init>(CodedInputStream.java:573)
	at com.google.protobuf.CodedInputStream.newInstance(CodedInputStream.java:55)
	at com.google.protobuf.AbstractParser.parsePartialFrom(AbstractParser.java:199)
	at com.google.protobuf.AbstractParser.parsePartialDelimitedFrom(AbstractParser.java:241)
	at com.google.protobuf.AbstractParser.parseDelimitedFrom(AbstractParser.java:253)
	at com.google.protobuf.AbstractParser.parseDelimitedFrom(AbstractParser.java:259)
	at com.google.protobuf.AbstractParser.parseDelimitedFrom(AbstractParser.java:49)
	at org.apache.hadoop.ipc.protobuf.RpcHeaderProtos$RpcResponseHeaderProto.parseDelimitedFrom(RpcHeaderProtos.java:3167)
	at org.apache.hadoop.ipc.Client$Connection.receiveRpcResponse(Client.java:1114)
	at org.apache.hadoop.ipc.Client$Connection.run(Client.java:1006)
19/10/30 22:18:22 INFO retry.RetryInvocationHandler: Exception while invoking renewLease of class ClientNamenodeProtocolTranslatorPB over master1.com.cn/192.168.189.15:8020. Trying to fail over immediately.
java.io.IOException: Failed on local exception: java.io.IOException: Error reading responses; Host Details : local host is: "bigdata2/192.168.179.2"; destination host is: "master1.com.cn":8020; 
	at org.apache.hadoop.net.NetUtils.wrapException(NetUtils.java:772)
	at org.apache.hadoop.ipc.Client.call(Client.java:1508)
	at org.apache.hadoop.ipc.Client.call(Client.java:1441)
	at org.apache.hadoop.ipc.ProtobufRpcEngine$Invoker.invoke(ProtobufRpcEngine.java:231)
	at com.sun.proxy.$Proxy10.renewLease(Unknown Source)
	at org.apache.hadoop.hdfs.protocolPB.ClientNamenodeProtocolTranslatorPB.renewLease(ClientNamenodeProtocolTranslatorPB.java:607)
	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.lang.reflect.Method.invoke(Method.java:498)
	at org.apache.hadoop.io.retry.RetryInvocationHandler.invokeMethod(RetryInvocationHandler.java:258)
	at org.apache.hadoop.io.retry.RetryInvocationHandler.invoke(RetryInvocationHandler.java:104)
	at com.sun.proxy.$Proxy11.renewLease(Unknown Source)
	at org.apache.hadoop.hdfs.DFSClient.renewLease(DFSClient.java:987)
	at org.apache.hadoop.hdfs.LeaseRenewer.renew(LeaseRenewer.java:398)
	at org.apache.hadoop.hdfs.LeaseRenewer.run(LeaseRenewer.java:423)
	at org.apache.hadoop.hdfs.LeaseRenewer.access$600(LeaseRenewer.java:72)
	at org.apache.hadoop.hdfs.LeaseRenewer$1.run(LeaseRenewer.java:302)
	at java.lang.Thread.run(Thread.java:748)
Caused by: java.io.IOException: Error reading responses
	at org.apache.hadoop.ipc.Client$Connection.run(Client.java:1013)
Caused by: java.lang.OutOfMemoryError: Java heap space
	at com.google.protobuf.CodedInputStream.<init>(CodedInputStream.java:573)
	at com.google.protobuf.CodedInputStream.newInstance(CodedInputStream.java:55)
	at com.google.protobuf.AbstractParser.parsePartialFrom(AbstractParser.java:199)
	at com.google.protobuf.AbstractParser.parsePartialDelimitedFrom(AbstractParser.java:241)
	at com.google.protobuf.AbstractParser.parseDelimitedFrom(AbstractParser.java:253)
	at com.google.protobuf.AbstractParser.parseDelimitedFrom(AbstractParser.java:259)
	at com.google.protobuf.AbstractParser.parseDelimitedFrom(AbstractParser.java:49)
	at org.apache.hadoop.ipc.protobuf.RpcHeaderProtos$RpcResponseHeaderProto.parseDelimitedFrom(RpcHeaderProtos.java:3167)
	at org.apache.hadoop.ipc.Client$Connection.receiveRpcResponse(Client.java:1114)
	at org.apache.hadoop.ipc.Client$Connection.run(Client.java:1006)
```
解决方案：将hdfs客户端Java堆内存调大，对于hadoop2来说，修改/etc/hadoop/conf/hadoop-env.sh。修改完了之后，立即生效。无需做其他操作。

```
# Prepend/Append plugin parcel classpaths

if [ "$HADOOP_USER_CLASSPATH_FIRST" = 'true' ]; then
  # HADOOP_CLASSPATH={{HADOOP_CLASSPATH_APPEND}}
  :
else
  # HADOOP_CLASSPATH={{HADOOP_CLASSPATH}}
  :
fi
# JAVA_LIBRARY_PATH={{JAVA_LIBRARY_PATH}}

export HADOOP_MAPRED_HOME=$( ([[ ! '/opt/cloudera/parcels/CDH/lib/hadoop-mapreduce' =~ CDH_MR2_HOME ]] && echo /opt/cloudera/parcels/CDH/lib/hadoop-mapreduce ) || echo ${CDH_MR2_HOME:-/usr/lib/hadoop-mapreduce/}  )
export YARN_OPTS="-Xmx1073741824 -Djava.net.preferIPv4Stack=true $YARN_OPTS"
#export HADOOP_CLIENT_OPTS="-Djava.net.preferIPv4Stack=true $HADOOP_CLIENT_OPTS"
#4G
export HADOOP_CLIENT_OPTS="-Xmx4294967296 -Djava.net.preferIPv4Stack=true $HADOOP_CLIENT_OPTS"
```
