title: Shell常用命令
date: '2019-10-25 17:34:08'
updated: '2019-10-27 11:11:41'
tags: [linux, shell]
permalink: /articles/2019/10/25/1571996048129.html
---
![戴帽子的动漫女生4K壁纸彼岸图网.jpg](https://img.hacpai.com/file/2019/10/戴帽子的动漫女生4K壁纸彼岸图网-cd50b55c.jpg)

# shell常用命令
记录一下shell脚本开发过程中常用的shell命令，便于以后查看。
## echo
echo命令是shell脚本中常用命令，主要用来输出日志信息。基本用法如下：

```
echo "shell脚本日志"
```
上面的语句日志会在终端中打印出来，然而有的时候，需要将日志信息输出到文件中：

```
#覆写shell.log文件
echo "shell脚本日志" > shell.log
#追加到shell.log文件
echo "shell脚本日志" >> shell.log
```
## 字符串切割为数组，并遍历
在写脚本的时候，经常需要将用特定字符分隔的字符串转换为数组，以便遍历：

```
string="a,b,c"
#切割为数组
array=(${string//,/ })
#获取数组长度
arrayLength=${#array[@]}
#遍历数组
index=0
while [[ ${index} < ${arrayLength} ]]
do
  echo "index is "${index}
  item=${array[$index]}
  echo "item is "${item}
  index=$(( ${index} + 1 ))
done
```
## 数值计算
### 整数计算
shell中整数计算的方法以下几种，**特别需要注意数值与符号之间的空格**：
```
#整数相加，注意有两层括号
index=$(( ${index} + 1 ))
#使用bc，bc命令是任意精度计算器语言，通常在linux下当计算器用
index=${index} + 1|bc
index=${index} - 1|bc
index=${index} \* 5|bc
index=${index} / 5|
#使用expr，expr命令是一个手工命令行计数器，用于在UNIX/LINUX下求表达式变量的值，一般用于整数值，也可用于字符串
index=`expr ${index} + 1`
```
## 比较判断
### 数值比较

```
#-eq 等于,如:if [[ "$a" -eq "$b" ]] 
#-ne 不等于,如:if [[ "$a" -ne "$b" ]]
#-gt 大于,如:if [[ "$a" -gt "$b" ]]
#-ge 大于等于,如:if [[ "$a" -ge "$b" ]] 
#-lt 小于,如:if [[ "$a" -lt "$b" ]]
#-le 小于等于,如:if [[ "$a" -le "$b" ]] 
if [[ ${num} -eq 0 ]]; then
   echo "num eq 0"
fi
```

### 字符串比较

```
#= 等于,如:if [[ "$a" = "$b" ]] 
#== 等于,如:if [[ "$a" == "$b" ]],与=等价
if [[ ${hostIp} == "localhost" ]]; then
    echo ""
fi
```

## 判断参数是否为空

```
#参数检测
if [[ ! -n ${businessNames} ]]; then
    echo "error! businessNames为空，请以-b传入"
    exit 1
fi
```

## 判断上一条命令是否执行成功

```
#执行成功返回0，执行失败返回值大于0
if [[ $? -gt 1 ]]; then
   echo "上条命令执行失败"
fi
```

## 换行符转换
将文件换行符有win格式转换为linux格式

```
perl -pi -e 's/\r\n/\n/g' test.sh
```

## 判断本地文件或文件夹是否存在

```
if [[ ! -d ${localPath} ]];then
   echo "error! "${localPath}"文件夹不存在"
   exit 1
else
   echo ${localPath}"文件夹存在"
fi

if [[ ! -f ${localFile} ]];then
   echo "error! "${localFile}"文件不存在"
   exit 1
else
   echo ${localFile}"文件存在"
fi
```

## hdfs常用命令

```
#查看hdfs目录文件
hdfs dfs -ls /data/
#查看hdfs文件大小
hdfs dfs -du -h /data/
#检测hdfs文件是否存在
hdfs dfs -test -f /data/hdfs_file
#检测hdfs目录是否存在
hdfs dfs -test -d /data/hdfs_path
#在hdfs中创建文件夹
hdfs dfs -mkdir -p /data/hdfs_path/test
#get文件到本地
hdfs dfs -get ${hdfs_path} ${local_path}
#put文件到hdfs
hdfs dfs -put ${local_path} ${hdfs_path}
```
