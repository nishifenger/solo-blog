title: HBase Java API FilterList使用小技巧
date: '2019-10-15 15:50:40'
updated: '2019-10-28 21:14:49'
tags: [hbase, Java, Api, filter]
permalink: /articles/2019/10/15/1571125840521.html
---
![781e236f721d78f108a65f726c093a32.jpg](https://img.hacpai.com/file/2019/10/781e236f721d78f108a65f726c093a32-3ae7b830.jpg)


# HBase Java API FilterList使用小技巧
HBase数据查询的时，常常会用到过滤器（需要注意的是过滤器都是作用于region中，跨region不能共享过滤器）。过滤器的种类非常多，如行过滤器（RowFilter）、列族过滤器（FamilyFilter）、列名过滤器（QualifierFilter）等。那么这么多类过滤，怎么组合才能满足我们的需求呢？这就是FilterList的作用了。
## FilterList
FilterList是用于组织多个过滤器，以便于使用这些过滤器共同限制返回到客户端的数据结果。那么FilterList在使用时，有哪些需要注意的技巧呢？个人觉得有以下两个
- FilterList可以通过控制加入过滤的顺序，控制多个过滤器的执行顺序。
- FilterList嵌套控制过滤器组合方式
### 执行顺序控制
下面通过一个具体的实例简单讲解一下，过滤器执行顺序控制的具体实现方式
HBase示例表结构如下：

**rowkey name**
family | qualifier
---|---|---
info | name 
info | age
info | email
info | id
需要实现的功能如下：
分页查询数据中age在[10,20]这个区间的前10条数据

实现代码如下：

```
SingleColumnValueFilter ageGreater =
        new SingleColumnValueFilter(Bytes.toBytes("info"), Bytes.toBytes("age"),
                CompareFilter.CompareOp.GREATER_OR_EQUAL, Bytes.toBytes(10));
SingleColumnValueFilter ageLess =
        new SingleColumnValueFilter(Bytes.toBytes("info"), Bytes.toBytes("age"),
                CompareFilter.CompareOp.LESS_OR_EQUAL, Bytes.toBytes(20));
PageFilter pageFilter = new PageFilter(10);
FilterList filterList = new FilterList();
filterList.addFilter(ageGreater);
filterList.addFilter(ageLess);
filterList.addFilter(pageFilter);
```
### FilterList嵌套控制过滤器组合方式
同样用一个实例讲解以下FilterList的嵌套

需要实现的功能如下：
分页查询数据中age在[0,10]或者[20,30]这个两个区间的前10条数据

如果说我们还是用之前的实现方法的话，得到的数据条数据为0条。为什么呢？

原因在FilterList默认的过滤器组合方式MUST_PASS_ALL，就是说只有满足所有过滤条件的数据才会返回给客户端。由于此次需要实现的功能中存在OR条件，所以不能使用MUST_PASS_ALL，需要使用MUST_PASS_ONE，既是只要满足其中一个条件即可。所以正确的实现方式如下：

```
SingleColumnValueFilter ageGreater0 =
                new SingleColumnValueFilter(Bytes.toBytes("info"), Bytes.toBytes("age"),
                        CompareFilter.CompareOp.GREATER_OR_EQUAL, Bytes.toBytes(0));
        SingleColumnValueFilter ageLess10 =
                new SingleColumnValueFilter(Bytes.toBytes("info"), Bytes.toBytes("age"),
                        CompareFilter.CompareOp.LESS_OR_EQUAL, Bytes.toBytes(10));
        FilterList listOne = new FilterList(FilterList.Operator.MUST_PASS_ALL);
        listOne.addFilter(ageGreater0);
        listOne.addFilter(ageLess10);
        SingleColumnValueFilter ageGreater20 =
                new SingleColumnValueFilter(Bytes.toBytes("info"), Bytes.toBytes("age"),
                        CompareFilter.CompareOp.GREATER_OR_EQUAL, Bytes.toBytes(20));
        SingleColumnValueFilter ageLess30 =
                new SingleColumnValueFilter(Bytes.toBytes("info"), Bytes.toBytes("age"),
                        CompareFilter.CompareOp.LESS_OR_EQUAL, Bytes.toBytes(30));
        FilterList listTwo = new FilterList(FilterList.Operator.MUST_PASS_ALL);
        listTwo.addFilter(ageGreater20);
        listTwo.addFilter(ageLess30);
        FilterList listThree = new FilterList(FilterList.Operator.MUST_PASS_ONE);
        listThree.addFilter(listOne);
        listThree.addFilter(listTwo);
        PageFilter pageFilter = new PageFilter(10);
        FilterList filterList = new FilterList(FilterList.Operator.MUST_PASS_ALL);
        filterList.addFilter(listThree);
        filterList.addFilter(pageFilter);
```
各个Filter以及FilterList之间的组合关系如下如所示：
![FilterList.png](https://img.hacpai.com/file/2019/10/FilterList-32fcadef.png)

