title: Java多线程学习笔记
date: '2019-11-20 09:38:00'
updated: '2019-11-20 09:39:15'
tags: [java, 多线程]
permalink: /articles/2019/11/20/1574213880466.html
---
1. 局部变量不会出现线程安全的问题
2. 对象变量（共享变量）会出现线程安全的问题
3. 脏读：简单理解就是读取的数据并非想要的数据。解决脏读的方法，是使用synchronized关键字对get方法进行同步。
4. A调用C synchronized关键字修饰方法，获取对象锁。当B调用C synchronized关键字修饰方法时，需要等待A释放锁，并由B获取锁。
5. synchronized锁重入：当一个线程得到一个对象锁后，再次请求此对象锁时，是可以得到该对象的锁的。所以在一个synchronized方法/块的内部调用本类的其他synchronized方法/块时，是永远可以得到锁的
6. 当一个线程执行代码出现异常时，其所持有的锁会自动释放
7. synchronized关键字不能被继承。所以在复写父类synchronized方法时，需要加上synchronized
8. 使用synchronized关键字声明方法，会使得方法中的代码全部被置于同步中。此时可以使用synchronized代码块来解决这个问题
9. synchronized(this){}, synchronized(非this){}
10. synchronized关键字加到static静态方法上是给Class类上锁，Class锁对所有Class的对象生效。而synchronized关键字加到非static静态方法上是对对象加锁。
11. 大多数情况下，同步synchronized代码块都不使用String作为锁对象。
12. 死锁：不同线程都在等待根本不可能被释放的锁
13. volatile与synchronized的比较
- volatile是线程同步的轻量级实现，所以volatile性能肯定比synchronized要好，并且volatile只能修饰变量，而synchronized可以修饰方法，代码块。
- 多线程访问volatile不会发生阻塞，而synchronized会出现阻塞
- volatile能保证数据的可见性，但不能保证原子性；而synchronized可以保证原子性，也可以间接保证可见性，因为synchronized会将私有内存和公共内存的数据做同步。
- volatile解决的是变量在多个线程之间的可见性，而synchronized解决的是多个线程之间的资源同步性

14. wait()方法的作用是使当前执行代码的线程进行等待，wait()方法是Object类的方法，该方法用来将当前线程置入“预执行队列”中，并且在wait()所在的代码行处停止执行，直到接到通知或被中断为止。在调用wait()之前，线程必须获得该对象的对象级别锁，既只能在同步方法或同步块中调用wait()方法。在执行wait()方法后，当前线程释放锁。在从wait()返回前，线程与其他线程竞争重新获取锁。如果调用wait()时没有持有适当的锁，则抛出IllegalMonitorStateException，它是RuntimeException的一个子类，因此，不需要try-catch语句进行捕捉异常。
15. notify()方法也要在同步方法或同步块中调用，在调用前，线程必须获取该对象的对象级别锁。如果调用notify()时没有持有适当的锁，会抛出IllegalMonitorStateException。该方法用来通知那些可能等待对象的对象锁的其他线程，如果有多个线程等待，则由线程规划器随机挑选出其中一个呈wait状态的线程，对其发出通知notify，并使它等待获取该对象的对象锁。需要说明的是，在执行notify()方法后，当前线程不会马上释放该对象锁，呈wait状态的线程也不能马上获取该对象锁，要等到执行notify()方法的线程将程序执行完，也就是退出synchronized语块后，当前线程才会释放锁，而呈wait状态所在的线程才可以获取该对象锁。当第一个获得了该对象锁的wait线程运行完毕以后，它会释放掉改对象锁，此时如果该对象没有再次使用notify语句，即便该对象已经空闲，其他wait状态等待的线程由于没有得到该对象的通知，还会继续阻塞在wait状态，直到这个对象发出一个notify或notifyAll。
16. wait(long)的功能是等待一段时间内是否有线程对锁进行唤醒，如果超过这个时间，则自动唤醒

17. join():如果主线程需要等待子线程执行完成之后再结束，如子线程处理一个数据，主线程要取得这个数据中的值，就要用到join()方法了。方法join()的作用是等待线程对象销毁。 
18. join(long):设定等待的时间
19. join(long)和sleep(long)的区别：join()的功能在内部是使用wait()方法来实现的，所以join()方法具有释放锁的特点。
