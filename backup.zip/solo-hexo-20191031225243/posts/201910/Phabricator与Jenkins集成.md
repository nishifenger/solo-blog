title: Phabricator与Jenkins集成
date: '2019-10-16 10:23:11'
updated: '2019-10-27 11:16:04'
tags: [phabricator, jenkins]
permalink: /articles/2019/10/16/1571192591454.html
---
![VioletEvergarden紫罗兰永恒花园薇尔莉特伊芙加登4k壁纸彼岸图网.jpg](https://img.hacpai.com/file/2019/10/VioletEvergarden紫罗兰永恒花园薇尔莉特伊芙加登4k壁纸彼岸图网-8938ecaf.jpg)


# Phabricator与Jenkins集成
Phabricator是一款开源的项目管理工具，其集成了项目管理、任务管理、代码仓库、代码审核、通知系统于一身。Jenkins是java项目中比较通用的持续集成工具，Phabricator与Jenkins集成可以实现项目自动构建（通过Phabricator中的Herald触发通知规则，通知规则调用Harbormaster，在Harbormaster中调用Jenkins中项目的远程构建url），并将构建相关信息（构建是否成功、单元测试覆盖率、sonar静态扫描结果）反馈回Phabricator，这些信息可以用于实现自动化code review。下面主要讲一下，如何进行集成以及相关的配置。

## 需要用到的工具
除了Phabricator以及Jenkins之外，还需要用到两个工具。一个是Phabricator Code Review插件Arcanist，其说明文档地址如下：https://secure.phabricator.com/book/phabricator/article/arcanist/；另一个是phabricator-jenkins-plugin。phabricator-jenkins-plugin是github上的一个开源项目，地址如下：https://github.com/uber/phabricator-jenkins-plugin。其说明文档比较详尽，基本上跟随说明文档进行配置，不会有什么问题，但是也还是有一些不够清楚的地方，后面我会讲到。

## 在Jenkins主机中安装Arcanist
安装Arcanist需要git环境，运行Arcanist需要php环境以及rsync。环境准备就绪了之后，就可以将Arcanist clone下来，命令如下：

```
git clone git://github.com/facebook/libphutil.git
git clone git://github.com/facebook/arcanist.git
```
随后将Arcanist中的arc命令软连接到系统环境中，或是在系统环境变量中添加相应的路径。或是在Jenkins配置中指明arc命令的绝对路径。到这里，Arcanist就安装完毕了。

## Jenkins插件安装
在Jenkins->系统管理->管理插件->可选插件 中搜索Phabricator，安装Phabricator Differential Plugin。安装完成之后，重启Jenkins。

## 在Phabricator中创建bot用户
在Phabricator->People中创建一个新的bot用户，并获取Conduit API Tokens。此用户是配置给Jenkins，使其有调用相关API的权限。具体操作以及页面如下图所示：

![bot.png](https://img.hacpai.com/file/2019/10/bot-63b8e51e.png)

![ConduitapiTokens.png](https://img.hacpai.com/file/2019/10/ConduitapiTokens-a0c11143.png)

## Phabricator Differential Plugin配置
在Phabricator Differential Plugin安装完成并生效之后，你会在Jenkins的系统管理->系统设置中看到Jenkins的配置模块，如下图所示：

![phabricatorplagin.png](https://img.hacpai.com/file/2019/10/phabricatorplagin-c47a9abd.png)

点击Add，新增一个Phabricator Credentials。示例页面如下：

![Credentials.png](https://img.hacpai.com/file/2019/10/Credentials-89d8e478.png)

图中Conduit Token就是上面创建的bot用户的Conduit API Tokens。
Location of arcanist就是arc命令的路径，如果你的arc命令是在环境变量中的，就可以不配置。否则需要配置出arc的绝对路径。

## Jenkins项目配置
完成了插件配置之后，下面就是具体的项目配置了。配置过程中需要注意的有以下几点：
- 参数化构建过程
在参数化构建过程中添加两个String Parameter参数。具体配置如下图所示：

![参数化配置.png](https://img.hacpai.com/file/2019/10/参数化配置-0a2218c0.png)

- 源码管理
源码管理使用git，如果配置了ssh，就不需要配置Credentials。但是个人建议使用的用户名和密码，这样方便进行权限管理。具体配置如下图所示：

![Git配置.png](https://img.hacpai.com/file/2019/10/Git配置-e55f5bc3.png)

- 构建触发器
因为需要配置远程构建，所以要配置构建触发器，已实现通过调用url远程触发项目构建。具体配置如下图所示：

![构建触发器.png](https://img.hacpai.com/file/2019/10/构建触发器-6e9ac766.png)

- 构建环境
构建环境具体配置如下图所示：

![构建环境.png](https://img.hacpai.com/file/2019/10/构建环境-b59f5bc1.png)

- Build
对于maven项目，构建命令如下：

```
clean verify -P dev cobertura:cobertura $SONAR_MAVEN_GOAL -Dsonar.analysis.mode=preview -Dsonar.issuesReport.html.enable=true -Dsonar.report.export.path=report.json -Dsonar.host.url=$SONAR_HOST_URL
```
其中cobertura:cobertura用于单元测覆盖率检测。
`$SONAR_MAVEN_GOAL -Dsonar.analysis.mode=preview -Dsonar.issuesReport.html.enable=true -Dsonar.report.export.path=report.json -Dsonar.host.url=$SONAR_HOST_URL`用于sonar扫描并生产报告文档。
具体配置如图所示：

![build.png](https://img.hacpai.com/file/2019/10/build-f6157e65.png)

- Post Steps
此配置主要是执行自定义的linux脚本，使用自主开发的插件程序，将sonar扫描报告转化为Phabricator-lint要求的格式，并写到.phabricator-lint文件中。具体配置如下图所示：

![PostSteps.png](https://img.hacpai.com/file/2019/10/PostSteps-50658a14.png)

其中jar包的运行命令如下，其中sonar-report-path为sonar报告的生成路径，一般为jenkins/jobs/项目名/workspace/target/sonar/report.json：

```
java -jar /jar-path/TransSonarReportToPhabricatorLint.jar /sonar-report-path/report.json .phabricator-lint
```
- 构建后操作
构建后操作中，主要有发布单元测试覆盖率报告，以及将相关信息发送给Phabricator。具体配置如下图所示：

![构建后操作.png](https://img.hacpai.com/file/2019/10/构建后操作-663686a4.png)

## 注意点
- .phabricator-lint文件格式
.phabricator-lint文件格式是很多用户都没有弄懂的地方，官方插件的说明文档也没有将此问题写得很清楚。相关的问题解答也十分混乱，导致很多人都没有弄明白此文件中json数据的具体格式。下面主要讲一下，此文件中json数据需要注意的点。
1. 整个文件不是一个标准的json文件，但每一行数据都是一条标准的json数据。
2. 每条数据中，各个关键字缺一不可。
示例数据如下：

```
{"name":"sonar issueMAJOR","code":"squid:S2629","severity":"advice","path":"src/main/java/com/cmiot/controller/UserActionsController.java","line":77,"char":0,"description":"Use the built-in formatting to construct this argument."}
{"name":"sonar issueCRITICAL","code":"squid:S1192","severity":"advice","path":"src/main/java/com/cmiot/controller/UserActionsController.java","line":48,"char":0,"description":"Define a constant instead of duplicating this literal \"welcome!\" 5 times."}
{"name":"sonar issueMAJOR","code":"squid:S3457","severity":"advice","path":"src/main/java/com/cmiot/controller/UserActionsController.java","line":77,"char":0,"description":"Format specifiers should be used instead of string concatenation."}
{"name":"sonar issueMINOR","code":"squid:S00116","severity":"advice","path":"src/main/java/com/cmiot/dto/FieldErrorDTO.java","line":8,"char":0,"description":"Rename this field \"FIELD\" to match the regular expression '^[a-z][a-zA-Z0-9]*$'."}
```
## Phabricator与jenkins集成效果展示
最后展示一下集成效果，如下图所示：
![集成效果1.png](https://img.hacpai.com/file/2019/10/集成效果1-1b0e6836.png)

![集成效果2.png](https://img.hacpai.com/file/2019/10/集成效果2-0ecaec6c.png)
